Gravity Wells (Alpha initial stable release)

This is a game project created by Laura/pinecubes (LauraHannah44.github.io).
This release is from 30/06/2020, built from the first instance of Python/Pygame code.

The game is not licensed for commercial use.
Free download is available via itch.io at https://pinecubes.itch.io/gravity-wells